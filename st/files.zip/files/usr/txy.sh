#!/bin/bash

secret_id="AKIDsdCXeYEgvysb9kJl15ygATbZLtDJDwTp"
secret_key="EG7kBRVN4XqzwgDWcdfZUTXXN0RegV6U"
service="ssl"
host="ssl.tencentcloudapi.com"
version="2019-12-05"

sign_request() {
    local action=$1
    local payload=$2
    local timestamp=$(date +%s)
    local date=$(date -u -d @$timestamp +"%Y-%m-%d")
    local canonical_headers="content-type:application/json; charset=utf-8\nhost:$host\nx-tc-action:${action,,}\n"
    local signed_headers="content-type;host;x-tc-action"
    local hashed_payload=$(echo -n "$payload" | openssl sha256 -hex | awk '{print $2}')
    local canonical_request="POST\n/\n\n$canonical_headers\n$signed_headers\n$hashed_payload"
    local credential_scope="$date/$service/tc3_request"
    local hashed_request=$(printf "$canonical_request" | openssl sha256 -hex | awk '{print $2}')
    local string_to_sign="TC3-HMAC-SHA256\n$timestamp\n$credential_scope\n$hashed_request"
    local secret_date=$(printf "$date" | openssl sha256 -hmac "TC3$secret_key" | awk '{print $2}')
    local secret_service=$(printf $service | openssl dgst -sha256 -mac hmac -macopt hexkey:"$secret_date" | awk '{print $2}')
    local secret_signing=$(printf "tc3_request" | openssl dgst -sha256 -mac hmac -macopt hexkey:"$secret_service" | awk '{print $2}')
    local signature=$(printf "$string_to_sign" | openssl dgst -sha256 -mac hmac -macopt hexkey:"$secret_signing" | awk '{print $2}')
    local authorization="TC3-HMAC-SHA256 Credential=$secret_id/$credential_scope, SignedHeaders=$signed_headers, Signature=$signature"
    wget -q -O - --header="Authorization: $authorization" \
                 --header="Content-Type: application/json; charset=utf-8" \
                 --header="Host: $host" \
                 --header="X-TC-Action: $action" \
                 --header="X-TC-Timestamp: $timestamp" \
                 --header="X-TC-Version: $version" \
                 --post-data="$payload" \
                 "https://$host"
}

response=$(sign_request "DescribeCertificates" "{}")
cert_id=$(echo "$response" | jsonfilter -e '@.Response.Certificates[@.Domain="d.acyun.us.kg" && @.Status=1].CertificateId' | sort -r | head -n 1)

echo -e "\n最晚到期的证书ID: $cert_id"

saved_cert_id=""
[ -f "/etc/zs/cert_id.txt" ] && saved_cert_id=$(cat /etc/zs/cert_id.txt)

if [ "$saved_cert_id" == "$cert_id" ]; then
    echo "证书ID未变更,无需下载"
    exit 0
fi

response_cert=$(sign_request "DownloadCertificate" "{\"CertificateId\":\"$cert_id\"}")
mkdir -p /etc/zs
echo "$response_cert" | jsonfilter -e '@.Response.Content' | tr -d '\n\r' | openssl base64 -d -A > /etc/zs/cert.zip

if cd /etc/zs && unzip -o cert.zip "Nginx/*"; then
    mv /etc/zs/Nginx/*.crt /etc/zs/uhttpd.crt
    mv /etc/zs/Nginx/*.key /etc/zs/uhttpd.key
    rm -rf /etc/zs/Nginx
    rm cert.zip
    echo "$cert_id" > /etc/zs/cert_id.txt
    echo "Nginx证书更新成功"
else
    echo "证书解压失败"
    exit 1
fi