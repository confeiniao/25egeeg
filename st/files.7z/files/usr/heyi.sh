#!/bin/ash

ra0_mac=""; rax0_mac=""
[ -f "/usr/ra0_mac.txt" ] && ra0_mac=$(cat /usr/ra0_mac.txt)
[ -f "/usr/rax0_mac.txt" ] && rax0_mac=$(cat /usr/rax0_mac.txt)

check_signal() {
    local dev=$1 mac_file=$2 signal_cond=$3 msg=$4 current_mac=$5 other_mac=$6
    iwinfo $dev assoclist | while read line; do
        case "$line" in 
            *dBm*)
                set -- $line
                mac=$1
                signal=$2
                case "$current_mac" in 
                    *"$mac"*)
                        ;;
                    *)
                        current_mac="$mac"$'\n'"$current_mac"
                        echo "$current_mac" > $mac_file
                        ;;
                esac
                case "$other_mac" in 
                    *"$mac"*)
                        [ "$signal" $signal_cond ] && {
                            iwpriv $dev set DisConnectSta=$mac
                            logger -t heyi "断开${msg}设备 @ $mac"
                        }
                        ;;
                esac
                ;;
        esac
    done
    echo "$current_mac"
}

while true; do
    ra0_mac=$(check_signal "ra0" "/usr/ra0_mac.txt" "-gt -48" "2.4G强信号" "$ra0_mac" "$rax0_mac")
    rax0_mac=$(check_signal "rax0" "/usr/rax0_mac.txt" "-lt -85" "5G弱信号" "$rax0_mac" "$ra0_mac")
    sleep 10
done