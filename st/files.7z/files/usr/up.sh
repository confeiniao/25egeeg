#!/bin/ash

SAVE_PATH="/usr/bin/AdGuardHome/data/filters/1736770951.txt"
TMP_PATH="/tmp/adguard_rules.txt"
URLS="https://mirror.ghproxy.com/https://raw.githubusercontent.com/confeiniao/25egeeg/main/st/ad.txt \
      https://ai.acyun.us.kg/https://raw.githubusercontent.com/confeiniao/25egeeg/main/st/ad.txt \
      https://raw.githubusercontent.com/confeiniao/25egeeg/main/st/ad.txt"
for URL in $URLS; do
    if wget -q -T 120 -O "$TMP_PATH" "$URL"; then
        mv "$TMP_PATH" "$SAVE_PATH"
        logger -t download_script "下载成功，下载URL：$URL"
        exit
    fi
done
logger -t download_script "所有下载源均失败"