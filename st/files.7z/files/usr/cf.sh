#!/bin/ash

attempt=0
while [ $attempt -lt 6 ]; do
    current_ipv6=$(ip -6 addr show dev pppoe-wan | awk '/inet6.*scope global/ {sub("/.*","", $2); print $2}')
    if [ -n "$current_ipv6" ]; then
        break
    fi
    attempt=$((attempt + 1))
    sleep 10
done

if [ -z "$current_ipv6" ]; then
    logger -t ds_cf_script "未能在6次尝试后获取到IPv6地址，脚本退出"
    exit 1
fi

saved_ipv6=""
[ -f "/usr/v6.txt" ] && saved_ipv6=$(cat /usr/v6.txt)

if [ "$current_ipv6" != "$saved_ipv6" ]; then
    CLOUDFLARE_ZONE_ID="e273eb3bfc6b4e6b91790c962d5e817a"
    CLOUDFLARE_RECORD_ID="b5b3d3aaf5f90389bc8341ff58526885"
    CLOUDFLARE_API_TOKEN="dfHwH9AncnSoZi6G3CCDS_D4TPa7rj3XLv3J0mXc"
    response=$(wget -qO- --method=PUT \
        --header="Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
        --header="Content-Type: application/json" \
        --body-data="{\"type\":\"AAAA\",\"name\":\"d.acyun.us.kg\",\"content\":\"$current_ipv6\",\"ttl\":1,\"proxied\":false}" \
        "https://api.cloudflare.com/client/v4/zones/$CLOUDFLARE_ZONE_ID/dns_records/$CLOUDFLARE_RECORD_ID")
    
    if echo "$response" | grep -q "\"success\":true"; then
        logger -t ds_cf_script "定时Cloudflare解析更新成功"
        echo "$current_ipv6" > /usr/v6.txt
        echo "$current_ipv6 d.acyun.us.kg" > /etc/hosts_v6
        sleep 1
        /etc/init.d/dnsmasq reload >/dev/null 2>&1 || logger -t ds_cf_script "dnsmasq重载失败"
    else
        logger -t ds_cf_script "定时Cloudflare解析更新失败"
    fi
else
    echo "定时IPv6地址未变化，无需更新"
fi